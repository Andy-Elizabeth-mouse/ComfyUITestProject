#include "ComfyUIClient.h"
#include "HttpModule.h"
#include "Interfaces/IHttpRequest.h"
#include "Interfaces/IHttpResponse.h"
#include "Engine/Engine.h"
#include "Engine/Texture2D.h"
#include "Engine/TextureDefines.h"
#include "ImageUtils.h"
#include "IImageWrapper.h"
#include "IImageWrapperModule.h"
#include "Modules/ModuleManager.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"
#include "TimerManager.h"
#include "HAL/PlatformFilemanager.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"

UComfyUIClient::UComfyUIClient()
{
    HttpModule = &FHttpModule::Get();
    ServerUrl = TEXT("http://127.0.0.1:8188");
    WorldContext = nullptr;
    InitializeWorkflowConfigs();
    LoadWorkflowConfigs();
}

void UComfyUIClient::SetWorldContext(UWorld* InWorld)
{
    WorldContext = InWorld;
}

void UComfyUIClient::SetServerUrl(const FString& Url)
{
    ServerUrl = Url;
}

void UComfyUIClient::InitializeWorkflowConfigs()
{
    // 清空硬编码的工作流配置，改为完全依赖动态加载
    WorkflowConfigs.Empty();
    
    UE_LOG(LogTemp, Log, TEXT("Initialized empty workflow configs - will load custom workflows from files"));
}

void UComfyUIClient::GenerateImage(const FString& Prompt, const FString& NegativePrompt, 
                                  EComfyUIWorkflowType WorkflowType, 
                                  const FOnImageGenerated& OnComplete)
{
    // 现在所有工作流都是自定义的，直接调用自定义工作流生成
    if (CustomWorkflowConfigs.Num() == 0)
    {
        UE_LOG(LogTemp, Error, TEXT("No custom workflows available. Please import a ComfyUI workflow first."));
        OnComplete.ExecuteIfBound(nullptr);
        return;
    }
    
    // 使用第一个可用的自定义工作流
    FString DefaultWorkflowName = CustomWorkflowConfigs[0].Name;
    UE_LOG(LogTemp, Warning, TEXT("Using default custom workflow: %s"), *DefaultWorkflowName);
    
    GenerateImageWithCustomWorkflow(Prompt, NegativePrompt, DefaultWorkflowName, OnComplete);
}

void UComfyUIClient::GenerateImageWithCustomWorkflow(const FString& Prompt, const FString& NegativePrompt,
                                                     const FString& CustomWorkflowName,
                                                     const FOnImageGenerated& OnComplete)
{
    OnImageGeneratedCallback = OnComplete;

    // 构建自定义工作流JSON
    FString WorkflowJson = BuildCustomWorkflowJson(Prompt, NegativePrompt, CustomWorkflowName);
    
    if (WorkflowJson.IsEmpty())
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to build custom workflow JSON for: %s"), *CustomWorkflowName);
        OnImageGeneratedCallback.ExecuteIfBound(nullptr);
        return;
    }

    // 创建HTTP请求
    CurrentRequest = HttpModule->CreateRequest();
    CurrentRequest->SetURL(ServerUrl + TEXT("/prompt"));
    CurrentRequest->SetVerb(TEXT("POST"));
    CurrentRequest->SetHeader(TEXT("Content-Type"), TEXT("application/json"));
    CurrentRequest->SetContentAsString(WorkflowJson);

    UE_LOG(LogTemp, Log, TEXT("GenerateImageWithCustomWorkflow: Sending prompt to %s"), *(ServerUrl + TEXT("/prompt")));
    UE_LOG(LogTemp, Log, TEXT("GenerateImageWithCustomWorkflow: Request JSON size: %d characters"), WorkflowJson.Len());

    // 绑定响应处理函数
    CurrentRequest->OnProcessRequestComplete().BindUObject(this, &UComfyUIClient::OnPromptSubmitted);

    // 发送请求
    CurrentRequest->ProcessRequest();
}

void UComfyUIClient::CheckServerStatus()
{
    // 创建服务器状态检查请求
    TSharedPtr<IHttpRequest, ESPMode::ThreadSafe> StatusRequest = HttpModule->CreateRequest();
    StatusRequest->SetURL(ServerUrl + TEXT("/system_stats"));
    StatusRequest->SetVerb(TEXT("GET"));
    StatusRequest->ProcessRequest();
}

void UComfyUIClient::GetAvailableWorkflows()
{
    // 刷新工作流列表
    LoadWorkflowConfigs();
}

TArray<FString> UComfyUIClient::GetAvailableWorkflowNames() const
{
    TArray<FString> WorkflowNames;
    
    // 添加预定义工作流
    for (const auto& Workflow : WorkflowConfigs)
    {
        WorkflowNames.Add(Workflow.Value.Name);
    }
    
    // 添加自定义工作流
    for (const auto& CustomWorkflow : CustomWorkflowConfigs)
    {
        WorkflowNames.Add(CustomWorkflow.Name);
    }
    
    return WorkflowNames;
}

FString UComfyUIClient::BuildWorkflowJson(const FString& Prompt, const FString& NegativePrompt, 
                                         EComfyUIWorkflowType WorkflowType)
{
    // 创建请求JSON对象
    TSharedPtr<FJsonObject> RequestJson = MakeShareable(new FJsonObject);
    RequestJson->SetStringField(TEXT("client_id"), TEXT("unreal_engine_plugin"));

    // 获取工作流配置
    FWorkflowConfig* Config = WorkflowConfigs.Find(WorkflowType);
    if (!Config)
    {
        UE_LOG(LogTemp, Error, TEXT("Workflow type not found"));
        return TEXT("{}");
    }

    // 解析工作流模板
    TSharedPtr<FJsonObject> WorkflowJson;
    TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Config->JsonTemplate);
    if (!FJsonSerializer::Deserialize(Reader, WorkflowJson))
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to parse workflow template"));
        return TEXT("{}");
    }

    // 替换模板中的占位符
    FString WorkflowString;
    TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&WorkflowString);
    FJsonSerializer::Serialize(WorkflowJson.ToSharedRef(), Writer);

    // 替换提示词占位符
    WorkflowString = WorkflowString.Replace(TEXT("{POSITIVE_PROMPT}"), *Prompt);
    WorkflowString = WorkflowString.Replace(TEXT("{NEGATIVE_PROMPT}"), *NegativePrompt);

    // 重新解析以确保JSON有效
    TSharedPtr<FJsonObject> FinalWorkflowJson;
    TSharedRef<TJsonReader<>> FinalReader = TJsonReaderFactory<>::Create(WorkflowString);
    if (FJsonSerializer::Deserialize(FinalReader, FinalWorkflowJson))
    {
        RequestJson->SetObjectField(TEXT("prompt"), FinalWorkflowJson);
    }

    // 序列化最终的请求JSON
    FString OutputString;
    TSharedRef<TJsonWriter<>> OutputWriter = TJsonWriterFactory<>::Create(&OutputString);
    FJsonSerializer::Serialize(RequestJson.ToSharedRef(), OutputWriter);

    return OutputString;
}

FString UComfyUIClient::BuildCustomWorkflowJson(const FString& Prompt, const FString& NegativePrompt,
                                               const FString& CustomWorkflowName)
{
    // 首先查找自定义工作流配置
    FWorkflowConfig* CustomConfig = nullptr;
    for (FWorkflowConfig& Config : CustomWorkflowConfigs)
    {
        if (Config.Name == CustomWorkflowName)
        {
            CustomConfig = &Config;
            break;
        }
    }
    
    if (!CustomConfig)
    {
        UE_LOG(LogTemp, Error, TEXT("Custom workflow not found: %s"), *CustomWorkflowName);
        return TEXT("{}");
    }
    
    // 创建请求JSON对象
    TSharedPtr<FJsonObject> RequestJson = MakeShareable(new FJsonObject);
    RequestJson->SetStringField(TEXT("client_id"), TEXT("unreal_engine_plugin"));

    // 如果有模板内容，使用模板
    FString WorkflowTemplate;
    if (!CustomConfig->JsonTemplate.IsEmpty())
    {
        WorkflowTemplate = CustomConfig->JsonTemplate;
        UE_LOG(LogTemp, Log, TEXT("BuildCustomWorkflowJson: Using cached template content"));
    }
    else if (!CustomConfig->TemplateFile.IsEmpty())
    {
        // 确保使用绝对路径
        FString TemplateFilePath = CustomConfig->TemplateFile;
        if (!FPaths::IsRelative(TemplateFilePath))
        {
            // 已经是绝对路径
        }
        else
        {
            // 相对路径，需要构造完整路径
            FString PluginDir = FPaths::ProjectPluginsDir() / TEXT("ComfyUIIntegration");
            FString TemplatesDir = PluginDir / TEXT("Config") / TEXT("Templates");
            TemplateFilePath = TemplatesDir / TemplateFilePath;
        }
        
        UE_LOG(LogTemp, Log, TEXT("BuildCustomWorkflowJson: Loading template from file: %s"), *TemplateFilePath);
        
        // 从文件加载模板
        if (!FFileHelper::LoadFileToString(WorkflowTemplate, *TemplateFilePath))
        {
            UE_LOG(LogTemp, Error, TEXT("Failed to load workflow template file: %s"), *TemplateFilePath);
            return TEXT("{}");
        }
        
        // 缓存模板内容以供下次使用
        CustomConfig->JsonTemplate = WorkflowTemplate;
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("No template found for custom workflow: %s"), *CustomWorkflowName);
        return TEXT("{}");
    }

    // 解析工作流模板
    TSharedPtr<FJsonObject> WorkflowJson;
    TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(WorkflowTemplate);
    if (!FJsonSerializer::Deserialize(Reader, WorkflowJson))
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to parse custom workflow template: %s"), *CustomWorkflowName);
        return TEXT("{}");
    }

    // 替换模板中的占位符
    FString WorkflowString;
    TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&WorkflowString);
    FJsonSerializer::Serialize(WorkflowJson.ToSharedRef(), Writer);

    // 替换提示词占位符
    WorkflowString = WorkflowString.Replace(TEXT("{POSITIVE_PROMPT}"), *Prompt);
    WorkflowString = WorkflowString.Replace(TEXT("{NEGATIVE_PROMPT}"), *NegativePrompt);
    
    // 替换其他自定义参数
    for (const auto& Param : CustomConfig->Parameters)
    {
        FString Placeholder = FString::Printf(TEXT("{%s}"), *Param.Key.ToUpper());
        WorkflowString = WorkflowString.Replace(*Placeholder, *Param.Value);
    }

    // 重新解析以确保JSON有效
    TSharedPtr<FJsonObject> FinalWorkflowJson;
    TSharedRef<TJsonReader<>> FinalReader = TJsonReaderFactory<>::Create(WorkflowString);
    if (FJsonSerializer::Deserialize(FinalReader, FinalWorkflowJson))
    {
        RequestJson->SetObjectField(TEXT("prompt"), FinalWorkflowJson);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to deserialize final workflow JSON"));
        return TEXT("{}");
    }

    // 序列化最终的请求JSON
    FString OutputString;
    TSharedRef<TJsonWriter<>> OutputWriter = TJsonWriterFactory<>::Create(&OutputString);
    FJsonSerializer::Serialize(RequestJson.ToSharedRef(), OutputWriter);

    UE_LOG(LogTemp, Log, TEXT("BuildCustomWorkflowJson: Final JSON being sent to ComfyUI:"));
    UE_LOG(LogTemp, Log, TEXT("%s"), *OutputString);

    return OutputString;
}

void UComfyUIClient::OnPromptSubmitted(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
    if (bWasSuccessful && Response.IsValid())
    {
        FString ResponseContent = Response->GetContentAsString();
        UE_LOG(LogTemp, Log, TEXT("Prompt submitted successfully: %s"), *ResponseContent);

        // 解析响应获取prompt_id
        TSharedPtr<FJsonObject> JsonObject;
        TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(ResponseContent);
        if (FJsonSerializer::Deserialize(Reader, JsonObject))
        {
            CurrentPromptId = JsonObject->GetStringField(TEXT("prompt_id"));
            if (!CurrentPromptId.IsEmpty())
            {
                // 开始轮询生成状态
                PollGenerationStatus(CurrentPromptId);
            }
            else
            {
                UE_LOG(LogTemp, Error, TEXT("No prompt_id in response"));
                OnImageGeneratedCallback.ExecuteIfBound(nullptr);
            }
        }
        else
        {
            UE_LOG(LogTemp, Error, TEXT("Failed to parse response JSON"));
            OnImageGeneratedCallback.ExecuteIfBound(nullptr);
        }
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to submit prompt to ComfyUI server"));
        OnImageGeneratedCallback.ExecuteIfBound(nullptr);
    }
}

void UComfyUIClient::PollGenerationStatus(const FString& PromptId)
{
    // 创建状态检查请求
    TSharedPtr<IHttpRequest, ESPMode::ThreadSafe> StatusRequest = HttpModule->CreateRequest();
    StatusRequest->SetURL(ServerUrl + TEXT("/history/") + PromptId);
    StatusRequest->SetVerb(TEXT("GET"));
    StatusRequest->OnProcessRequestComplete().BindUObject(this, &UComfyUIClient::OnQueueStatusChecked);
    StatusRequest->ProcessRequest();
}

void UComfyUIClient::OnQueueStatusChecked(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
    if (bWasSuccessful && Response.IsValid())
    {
        FString ResponseContent = Response->GetContentAsString();
        UE_LOG(LogTemp, Log, TEXT("Queue status response: %s"), *ResponseContent);
        
        // 解析响应检查是否完成
        TSharedPtr<FJsonObject> JsonObject;
        TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(ResponseContent);
        if (FJsonSerializer::Deserialize(Reader, JsonObject))
        {
            // 检查是否有历史记录（表示完成）
            if (JsonObject->HasField(CurrentPromptId))
            {
                // 生成完成，获取输出信息
                TSharedPtr<FJsonObject> PromptHistory = JsonObject->GetObjectField(CurrentPromptId);
                if (PromptHistory.IsValid() && PromptHistory->HasField(TEXT("outputs")))
                {
                    TSharedPtr<FJsonObject> Outputs = PromptHistory->GetObjectField(TEXT("outputs"));
                    
                    // 查找图像输出节点（通常是SaveImage节点）
                    for (auto& OutputPair : Outputs->Values)
                    {
                        TSharedPtr<FJsonObject> OutputNode = OutputPair.Value->AsObject();
                        if (OutputNode.IsValid() && OutputNode->HasField(TEXT("images")))
                        {
                            const TArray<TSharedPtr<FJsonValue>>* ImagesArray;
                            if (OutputNode->TryGetArrayField(TEXT("images"), ImagesArray) && ImagesArray->Num() > 0)
                            {
                                // 获取第一张图片的信息
                                TSharedPtr<FJsonObject> ImageInfo = (*ImagesArray)[0]->AsObject();
                                if (ImageInfo.IsValid())
                                {
                                    FString Filename = ImageInfo->GetStringField(TEXT("filename"));
                                    FString Subfolder = ImageInfo->GetStringField(TEXT("subfolder"));
                                    FString Type = ImageInfo->GetStringField(TEXT("type"));
                                    
                                    UE_LOG(LogTemp, Log, TEXT("Found generated image: %s in %s"), *Filename, *Subfolder);
                                    
                                    // 下载图片
                                    DownloadGeneratedImage(Filename, Subfolder, Type);
                                    return;
                                }
                            }
                        }
                    }
                }
                
                // 如果没有找到图片输出，报告错误
                UE_LOG(LogTemp, Error, TEXT("No image outputs found in completed generation"));
                OnImageGeneratedCallback.ExecuteIfBound(nullptr);
            }
            else
            {
                // 还未完成，继续轮询
                if (WorldContext.IsValid())
                {
                    WorldContext->GetTimerManager().SetTimer(StatusPollTimer, 
                        FTimerDelegate::CreateLambda([this]() { PollGenerationStatus(CurrentPromptId); }),
                        2.0f, false); // 2秒后再次检查
                }
                else
                {
                    UE_LOG(LogTemp, Error, TEXT("Invalid world context for timer management"));
                    OnImageGeneratedCallback.ExecuteIfBound(nullptr);
                }
            }
        }
        else
        {
            UE_LOG(LogTemp, Error, TEXT("Failed to parse status response"));
            OnImageGeneratedCallback.ExecuteIfBound(nullptr);
        }
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to check generation status"));
        OnImageGeneratedCallback.ExecuteIfBound(nullptr);
    }
}

void UComfyUIClient::OnImageDownloaded(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
    if (bWasSuccessful && Response.IsValid())
    {
        // 获取图像数据
        TArray<uint8> ImageData = Response->GetContent();
        
        UE_LOG(LogTemp, Log, TEXT("Downloaded image data: %d bytes"), ImageData.Num());
        
        // 创建纹理
        UTexture2D* GeneratedTexture = CreateTextureFromImageData(ImageData);
        
        if (GeneratedTexture)
        {
            UE_LOG(LogTemp, Log, TEXT("Successfully created texture: %dx%d"), 
                   GeneratedTexture->GetSizeX(), GeneratedTexture->GetSizeY());
        }
        else
        {
            UE_LOG(LogTemp, Error, TEXT("Failed to create texture from image data"));
        }
        
        OnImageGeneratedCallback.ExecuteIfBound(GeneratedTexture);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to download generated image - HTTP Status: %d"), 
               Response.IsValid() ? Response->GetResponseCode() : 0);
        OnImageGeneratedCallback.ExecuteIfBound(nullptr);
    }
}

UTexture2D* UComfyUIClient::CreateTextureFromImageData(const TArray<uint8>& ImageData)
{
    if (ImageData.Num() == 0)
    {
        UE_LOG(LogTemp, Error, TEXT("Empty image data"));
        return nullptr;
    }

    // 使用ImageWrapper模块来解码图像
    IImageWrapperModule& ImageWrapperModule = FModuleManager::LoadModuleChecked<IImageWrapperModule>(FName("ImageWrapper"));
    
    // 尝试不同的图像格式
    TArray<EImageFormat> FormatsToTry = {
        EImageFormat::PNG,
        EImageFormat::JPEG,
        EImageFormat::BMP,
        EImageFormat::TIFF
    };
    
    for (EImageFormat Format : FormatsToTry)
    {
        TSharedPtr<IImageWrapper> ImageWrapper = ImageWrapperModule.CreateImageWrapper(Format);
        if (!ImageWrapper.IsValid())
        {
            continue;
        }

        if (ImageWrapper->SetCompressed(ImageData.GetData(), ImageData.Num()))
        {
            UE_LOG(LogTemp, Log, TEXT("Successfully decoded image as format: %d"), static_cast<int32>(Format));
            
            TArray<uint8> UncompressedBGRA;
            if (ImageWrapper->GetRaw(ERGBFormat::BGRA, 8, UncompressedBGRA))
            {
                // 创建纹理
                int32 Width = ImageWrapper->GetWidth();
                int32 Height = ImageWrapper->GetHeight();
                
                UE_LOG(LogTemp, Log, TEXT("Creating texture: %dx%d"), Width, Height);
                
                // 创建一个可持久化的纹理，而不是临时纹理
                UTexture2D* Texture = NewObject<UTexture2D>();
                if (Texture)
                {
                    // 初始化纹理源数据
                    Texture->Source.Init(Width, Height, 1, 1, TSF_BGRA8, UncompressedBGRA.GetData());
                    
                    // 设置纹理属性
                    Texture->CompressionSettings = TextureCompressionSettings::TC_Default;
                    Texture->Filter = TextureFilter::TF_Default;
                    Texture->AddressX = TextureAddress::TA_Clamp;
                    Texture->AddressY = TextureAddress::TA_Clamp;
                    Texture->LODGroup = TextureGroup::TEXTUREGROUP_UI;
                    Texture->SRGB = true;
                    Texture->MipGenSettings = TMGS_NoMipmaps;
                    
                    // 标记为需要更新，并触发立即构建
                    Texture->PostEditChange();
                    Texture->UpdateResource();
                    
                    UE_LOG(LogTemp, Log, TEXT("Persistent texture created successfully with %d mips"), 
                           Texture->GetPlatformData() ? Texture->GetPlatformData()->Mips.Num() : 0);
                    return Texture;
                }
                else
                {
                    UE_LOG(LogTemp, Error, TEXT("Failed to create UTexture2D"));
                }
            }
            else
            {
                UE_LOG(LogTemp, Error, TEXT("Failed to get raw image data"));
            }
        }
    }

    UE_LOG(LogTemp, Error, TEXT("Failed to decode image data with any supported format"));
    return nullptr;
}

void UComfyUIClient::LoadWorkflowConfigs()
{
    // 获取插件配置目录
    FString PluginDir = FPaths::ProjectPluginsDir() / TEXT("ComfyUIIntegration");
    FString ConfigPath = PluginDir / TEXT("Config") / TEXT("default_config.json");
    
    // 检查配置文件是否存在
    if (!FPaths::FileExists(ConfigPath))
    {
        UE_LOG(LogTemp, Warning, TEXT("Config file not found: %s"), *ConfigPath);
        return;
    }
    
    // 读取配置文件
    FString ConfigContent;
    if (!FFileHelper::LoadFileToString(ConfigContent, *ConfigPath))
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to load config file: %s"), *ConfigPath);
        return;
    }
    
    // 解析JSON配置
    TSharedPtr<FJsonObject> ConfigJson;
    TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(ConfigContent);
    if (!FJsonSerializer::Deserialize(Reader, ConfigJson))
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to parse config JSON"));
        return;
    }
    
    // 读取服务器设置
    if (ConfigJson->HasField(TEXT("server_settings")))
    {
        TSharedPtr<FJsonObject> ServerSettings = ConfigJson->GetObjectField(TEXT("server_settings"));
        if (ServerSettings->HasField(TEXT("default_url")))
        {
            ServerUrl = ServerSettings->GetStringField(TEXT("default_url"));
        }
    }
    
    // 读取工作流配置
    if (ConfigJson->HasField(TEXT("workflows")))
    {
        const TArray<TSharedPtr<FJsonValue>>* WorkflowArray;
        if (ConfigJson->TryGetArrayField(TEXT("workflows"), WorkflowArray))
        {
            for (const auto& WorkflowValue : *WorkflowArray)
            {
                TSharedPtr<FJsonObject> WorkflowObj = WorkflowValue->AsObject();
                if (WorkflowObj.IsValid())
                {
                    FWorkflowConfig CustomConfig;
                    CustomConfig.Name = WorkflowObj->GetStringField(TEXT("name"));
                    CustomConfig.Type = WorkflowObj->GetStringField(TEXT("type"));
                    CustomConfig.Description = WorkflowObj->GetStringField(TEXT("description"));
                    
                    // 读取模板文件路径
                    if (WorkflowObj->HasField(TEXT("template")))
                    {
                        CustomConfig.TemplateFile = WorkflowObj->GetStringField(TEXT("template"));
                    }
                    
                    // 读取参数
                    if (WorkflowObj->HasField(TEXT("parameters")))
                    {
                        TSharedPtr<FJsonObject> ParamsObj = WorkflowObj->GetObjectField(TEXT("parameters"));
                        for (auto& Param : ParamsObj->Values)
                        {
                            FString ValueStr;
                            if (Param.Value->TryGetString(ValueStr))
                            {
                                CustomConfig.Parameters.Add(Param.Key, ValueStr);
                            }
                            else if (Param.Value->Type == EJson::Number)
                            {
                                double NumValue = Param.Value->AsNumber();
                                CustomConfig.Parameters.Add(Param.Key, FString::SanitizeFloat(NumValue));
                            }
                            else if (Param.Value->Type == EJson::Boolean)
                            {
                                bool BoolValue = Param.Value->AsBool();
                                CustomConfig.Parameters.Add(Param.Key, BoolValue ? TEXT("true") : TEXT("false"));
                            }
                        }
                    }
                    
                    CustomWorkflowConfigs.Add(CustomConfig);
                    UE_LOG(LogTemp, Log, TEXT("Loaded custom workflow: %s"), *CustomConfig.Name);
                }
            }
        }
    }
    
    // 加载工作流模板目录中的额外工作流
    FString TemplatesDir = PluginDir / TEXT("Config") / TEXT("Templates");
    if (FPaths::DirectoryExists(TemplatesDir))
    {
        TArray<FString> TemplateFiles;
        IFileManager::Get().FindFiles(TemplateFiles, *(TemplatesDir / TEXT("*.json")), true, false);
        
        for (const FString& TemplateFile : TemplateFiles)
        {
            FString FullPath = TemplatesDir / TemplateFile;
            LoadCustomWorkflowFromFile(FullPath);
        }
    }
}

bool UComfyUIClient::LoadCustomWorkflowFromFile(const FString& FilePath)
{
    if (!FPaths::FileExists(FilePath))
    {
        UE_LOG(LogTemp, Warning, TEXT("Workflow template file not found: %s"), *FilePath);
        return false;
    }
    
    FString TemplateContent;
    if (!FFileHelper::LoadFileToString(TemplateContent, *FilePath))
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to load workflow template: %s"), *FilePath);
        return false;
    }
    
    // 验证JSON格式
    TSharedPtr<FJsonObject> TemplateJson;
    TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(TemplateContent);
    if (!FJsonSerializer::Deserialize(Reader, TemplateJson))
    {
        UE_LOG(LogTemp, Error, TEXT("Invalid JSON in workflow template: %s"), *FilePath);
        return false;
    }
    
    // 创建工作流配置
    FWorkflowConfig NewWorkflow;
    FString FileName = FPaths::GetBaseFilename(FilePath);
    NewWorkflow.Name = FileName;
    NewWorkflow.Type = TEXT("custom");
    NewWorkflow.Description = FString::Printf(TEXT("Custom workflow loaded from %s"), *FileName);
    NewWorkflow.JsonTemplate = TemplateContent;
    NewWorkflow.TemplateFile = FilePath;
    
    CustomWorkflowConfigs.Add(NewWorkflow);
    UE_LOG(LogTemp, Log, TEXT("Loaded custom workflow template: %s"), *NewWorkflow.Name);
    
    return true;
}

void UComfyUIClient::DownloadGeneratedImage(const FString& Filename, const FString& Subfolder, const FString& Type)
{
    // 构建图片下载URL
    FString ImageUrl = ServerUrl + TEXT("/view");
    
    // 添加查询参数
    TArray<FString> QueryParams;
    QueryParams.Add(FString::Printf(TEXT("filename=%s"), *FGenericPlatformHttp::UrlEncode(Filename)));
    
    if (!Subfolder.IsEmpty())
    {
        QueryParams.Add(FString::Printf(TEXT("subfolder=%s"), *FGenericPlatformHttp::UrlEncode(Subfolder)));
    }
    
    if (!Type.IsEmpty())
    {
        QueryParams.Add(FString::Printf(TEXT("type=%s"), *FGenericPlatformHttp::UrlEncode(Type)));
    }
    
    if (QueryParams.Num() > 0)
    {
        ImageUrl += TEXT("?") + FString::Join(QueryParams, TEXT("&"));
    }
    
    UE_LOG(LogTemp, Log, TEXT("Downloading image from: %s"), *ImageUrl);
    
    // 创建下载请求
    TSharedPtr<IHttpRequest, ESPMode::ThreadSafe> DownloadRequest = HttpModule->CreateRequest();
    DownloadRequest->SetURL(ImageUrl);
    DownloadRequest->SetVerb(TEXT("GET"));
    DownloadRequest->OnProcessRequestComplete().BindUObject(this, &UComfyUIClient::OnImageDownloaded);
    DownloadRequest->ProcessRequest();
}

// ========== 工作流验证和管理功能 ==========

bool UComfyUIClient::ValidateWorkflowFile(const FString& FilePath, FString& OutError)
{
    OutError.Empty();
    
    // 检查文件是否存在
    if (!FPaths::FileExists(FilePath))
    {
        OutError = FString::Printf(TEXT("Workflow file not found: %s"), *FilePath);
        return false;
    }
    
    // 读取文件内容
    FString JsonContent;
    if (!FFileHelper::LoadFileToString(JsonContent, *FilePath))
    {
        OutError = FString::Printf(TEXT("Failed to read workflow file: %s"), *FilePath);
        return false;
    }
    
    // 验证JSON格式和工作流结构
    FWorkflowConfig TempConfig;
    return ValidateWorkflowJson(JsonContent, TempConfig, OutError);
}

bool UComfyUIClient::ImportWorkflowFile(const FString& FilePath, const FString& WorkflowName, FString& OutError)
{
    OutError.Empty();
    
    // 首先验证工作流
    if (!ValidateWorkflowFile(FilePath, OutError))
    {
        return false;
    }
    
    // 读取工作流内容
    FString JsonContent;
    if (!FFileHelper::LoadFileToString(JsonContent, *FilePath))
    {
        OutError = TEXT("Failed to read workflow file");
        return false;
    }
    
    // 创建工作流配置
    FWorkflowConfig NewWorkflow;
    if (!ValidateWorkflowJson(JsonContent, NewWorkflow, OutError))
    {
        return false;
    }
    
    // 设置工作流信息
    NewWorkflow.Name = SanitizeWorkflowName(WorkflowName);
    NewWorkflow.Type = TEXT("custom");
    NewWorkflow.Description = FString::Printf(TEXT("Custom workflow: %s"), *NewWorkflow.Name);
    NewWorkflow.JsonTemplate = JsonContent;
    NewWorkflow.TemplateFile = FilePath;
    
    // 保存到插件目录
    FString PluginDir = FPaths::ProjectPluginsDir() / TEXT("ComfyUIIntegration");
    FString TemplatesDir = PluginDir / TEXT("Config") / TEXT("Templates");
    FString TargetFile = TemplatesDir / (NewWorkflow.Name + TEXT(".json"));
    
    UE_LOG(LogTemp, Log, TEXT("ImportWorkflow: Source file: %s"), *FilePath);
    UE_LOG(LogTemp, Log, TEXT("ImportWorkflow: Target directory: %s"), *TemplatesDir);
    UE_LOG(LogTemp, Log, TEXT("ImportWorkflow: Target file: %s"), *TargetFile);
    
    // 确保目录存在
    if (!FPaths::DirectoryExists(TemplatesDir))
    {
        UE_LOG(LogTemp, Log, TEXT("ImportWorkflow: Creating templates directory"));
        if (!IFileManager::Get().MakeDirectory(*TemplatesDir, true))
        {
            OutError = FString::Printf(TEXT("Failed to create templates directory: %s"), *TemplatesDir);
            UE_LOG(LogTemp, Error, TEXT("ImportWorkflow: %s"), *OutError);
            return false;
        }
    }
    
    // 验证源文件存在
    if (!FPaths::FileExists(FilePath))
    {
        OutError = FString::Printf(TEXT("Source workflow file not found: %s"), *FilePath);
        UE_LOG(LogTemp, Error, TEXT("ImportWorkflow: %s"), *OutError);
        return false;
    }
    
    // 使用 FFileHelper 复制文件（更可靠）
    UE_LOG(LogTemp, Log, TEXT("ImportWorkflow: Saving workflow content to target file"));
    if (!FFileHelper::SaveStringToFile(JsonContent, *TargetFile))
    {
        OutError = FString::Printf(TEXT("Failed to save workflow to: %s"), *TargetFile);
        UE_LOG(LogTemp, Error, TEXT("ImportWorkflow: %s"), *OutError);
        return false;
    }
    
    // 验证文件是否成功创建
    if (!FPaths::FileExists(TargetFile))
    {
        OutError = FString::Printf(TEXT("Workflow file was not created at: %s"), *TargetFile);
        UE_LOG(LogTemp, Error, TEXT("ImportWorkflow: %s"), *OutError);
        return false;
    }
    
    // 添加到配置列表
    CustomWorkflowConfigs.Add(NewWorkflow);
    
    UE_LOG(LogTemp, Log, TEXT("Successfully imported workflow: %s"), *NewWorkflow.Name);
    return true;
}

TArray<FString> UComfyUIClient::GetWorkflowParameterNames(const FString& WorkflowName) const
{
    TArray<FString> ParameterNames;
    
    // 查找工作流配置
    const FWorkflowConfig* FoundConfig = nullptr;
    for (const auto& Config : CustomWorkflowConfigs)
    {
        if (Config.Name == WorkflowName)
        {
            FoundConfig = &Config;
            break;
        }
    }
    
    if (FoundConfig)
    {
        for (const auto& ParamDef : FoundConfig->ParameterDefinitions)
        {
            ParameterNames.Add(ParamDef.Name);
        }
    }
    
    return ParameterNames;
}

void UComfyUIClient::TestWorkflowConnection()
{
    // 测试服务器连接
    TSharedPtr<IHttpRequest, ESPMode::ThreadSafe> TestRequest = HttpModule->CreateRequest();
    TestRequest->SetURL(ServerUrl + TEXT("/system_stats"));
    TestRequest->SetVerb(TEXT("GET"));
    TestRequest->OnProcessRequestComplete().BindLambda([this](FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
    {
        if (bWasSuccessful && Response.IsValid())
        {
            UE_LOG(LogTemp, Log, TEXT("ComfyUI server connection successful"));
            UE_LOG(LogTemp, Log, TEXT("Server response: %s"), *Response->GetContentAsString());
        }
        else
        {
            UE_LOG(LogTemp, Error, TEXT("Failed to connect to ComfyUI server at: %s"), *ServerUrl);
        }
    });
    TestRequest->ProcessRequest();
}

void UComfyUIClient::TestServerConnection(const FOnConnectionTested& OnComplete)
{
    if (ServerUrl.IsEmpty())
    {
        OnComplete.ExecuteIfBound(false, TEXT("服务器URL为空"));
        return;
    }

    // 首先尝试最基本的连接测试
    TSharedPtr<IHttpRequest, ESPMode::ThreadSafe> TestRequest = HttpModule->CreateRequest();
    
    // ComfyUI通常在根路径有一个简单的响应，或者可以用/system_stats
    FString TestUrl = ServerUrl;
    if (!TestUrl.EndsWith(TEXT("/")))
    {
        TestUrl += TEXT("/");
    }
    
    TestRequest->SetURL(TestUrl);
    TestRequest->SetVerb(TEXT("GET"));
    TestRequest->SetTimeout(5.0f); // 5秒超时
    
    TestRequest->OnProcessRequestComplete().BindLambda([this, OnComplete](FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
    {
        if (bWasSuccessful && Response.IsValid())
        {
            int32 ResponseCode = Response->GetResponseCode();
            if (ResponseCode == 200)
            {
                // 检查响应内容是否表明这是ComfyUI服务器
                FString Content = Response->GetContentAsString();
                if (Content.Contains(TEXT("ComfyUI")) || Content.Contains(TEXT("comfyui")))
                {
                    OnComplete.ExecuteIfBound(true, TEXT(""));
                    return;
                }
            }
            
            // 如果根路径不行，试试/system_stats端点（ComfyUI的标准API端点）
            TSharedPtr<IHttpRequest, ESPMode::ThreadSafe> StatsRequest = HttpModule->CreateRequest();
            FString StatsUrl = ServerUrl;
            if (!StatsUrl.EndsWith(TEXT("/")))
            {
                StatsUrl += TEXT("/");
            }
            StatsUrl += TEXT("system_stats");
            
            StatsRequest->SetURL(StatsUrl);
            StatsRequest->SetVerb(TEXT("GET"));
            StatsRequest->SetTimeout(5.0f);
            
            StatsRequest->OnProcessRequestComplete().BindLambda([OnComplete](FHttpRequestPtr StatsReq, FHttpResponsePtr StatsResp, bool bStatsSuccess)
            {
                if (bStatsSuccess && StatsResp.IsValid() && StatsResp->GetResponseCode() == 200)
                {
                    FString StatsContent = StatsResp->GetContentAsString();
                    // 检查是否包含ComfyUI系统信息的特征
                    if (StatsContent.Contains(TEXT("system")) || StatsContent.Contains(TEXT("memory")) || !StatsContent.IsEmpty())
                    {
                        OnComplete.ExecuteIfBound(true, TEXT(""));
                    }
                    else
                    {
                        OnComplete.ExecuteIfBound(false, TEXT("服务器响应异常，可能不是ComfyUI服务器"));
                    }
                }
                else
                {
                    OnComplete.ExecuteIfBound(false, TEXT("ComfyUI服务器未响应或不可用"));
                }
            });
            
            StatsRequest->ProcessRequest();
        }
        else
        {
            FString ErrorMsg = TEXT("无法连接到ComfyUI服务器");
            if (Response.IsValid())
            {
                ErrorMsg += FString::Printf(TEXT(" (HTTP %d)"), Response->GetResponseCode());
            }
            else
            {
                ErrorMsg += TEXT(" (网络错误或超时)");
            }
            OnComplete.ExecuteIfBound(false, ErrorMsg);
        }
    });
    
    TestRequest->ProcessRequest();
}

bool UComfyUIClient::ValidateWorkflowJson(const FString& JsonContent, FWorkflowConfig& OutConfig, FString& OutError)
{
    OutError.Empty();
    
    // 解析JSON
    TSharedPtr<FJsonObject> WorkflowJson;
    TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonContent);
    if (!FJsonSerializer::Deserialize(Reader, WorkflowJson))
    {
        OutError = TEXT("Invalid JSON format");
        return false;
    }
    
    if (!WorkflowJson.IsValid())
    {
        OutError = TEXT("Empty or invalid workflow JSON");
        return false;
    }
    
    // 检查是否是有效的ComfyUI工作流格式
    bool bHasValidNodes = false;
    for (const auto& NodePair : WorkflowJson->Values)
    {
        if (NodePair.Value->Type == EJson::Object)
        {
            TSharedPtr<FJsonObject> NodeObj = NodePair.Value->AsObject();
            if (NodeObj->HasField(TEXT("class_type")))
            {
                bHasValidNodes = true;
                break;
            }
        }
    }
    
    if (!bHasValidNodes)
    {
        OutError = TEXT("No valid ComfyUI nodes found. Make sure this is a ComfyUI workflow export.");
        return false;
    }
    
    // 分析工作流节点
    if (!AnalyzeWorkflowNodes(WorkflowJson, OutConfig))
    {
        OutError = TEXT("Failed to analyze workflow structure");
        return false;
    }
    
    // 查找输入和输出节点
    if (!FindWorkflowInputs(WorkflowJson, OutConfig.RequiredInputs))
    {
        UE_LOG(LogTemp, Warning, TEXT("No input parameters found in workflow"));
    }
    
    if (!FindWorkflowOutputs(WorkflowJson, OutConfig.OutputNodes))
    {
        OutError = TEXT("No output nodes found. Workflow must have at least one SaveImage or PreviewImage node.");
        return false;
    }
    
    OutConfig.bIsValid = true;
    OutConfig.JsonTemplate = JsonContent;
    
    UE_LOG(LogTemp, Log, TEXT("Workflow validation successful. Found %d inputs and %d outputs"), 
           OutConfig.RequiredInputs.Num(), OutConfig.OutputNodes.Num());
    
    return true;
}

bool UComfyUIClient::AnalyzeWorkflowNodes(TSharedPtr<FJsonObject> WorkflowJson, FWorkflowConfig& OutConfig)
{
    if (!WorkflowJson.IsValid())
    {
        return false;
    }
    
    OutConfig.ParameterDefinitions.Empty();
    
    // 遍历所有节点
    for (const auto& NodePair : WorkflowJson->Values)
    {
        FString NodeId = NodePair.Key;
        TSharedPtr<FJsonObject> NodeObj = NodePair.Value->AsObject();
        
        if (!NodeObj.IsValid() || !NodeObj->HasField(TEXT("class_type")))
        {
            continue;
        }
        
        FString ClassType = NodeObj->GetStringField(TEXT("class_type"));
        
        // 检查常见的输入节点类型
        if (ClassType == TEXT("CLIPTextEncode") || ClassType == TEXT("PromptText"))
        {
            // 文本输入节点
            FWorkflowConfig::FParameterDef PromptParam;
            PromptParam.Name = FString::Printf(TEXT("prompt_%s"), *NodeId);
            PromptParam.Type = TEXT("text");
            PromptParam.DefaultValue = TEXT("");
            PromptParam.Description = FString::Printf(TEXT("Text prompt for node %s"), *NodeId);
            OutConfig.ParameterDefinitions.Add(PromptParam);
        }
        else if (ClassType == TEXT("KSampler") || ClassType == TEXT("SamplerCustom"))
        {
            // 采样器节点 - 添加常见参数
            if (NodeObj->HasField(TEXT("inputs")))
            {
                TSharedPtr<FJsonObject> InputsObj = NodeObj->GetObjectField(TEXT("inputs"));
                
                // Steps参数
                if (InputsObj->HasField(TEXT("steps")))
                {
                    FWorkflowConfig::FParameterDef StepsParam;
                    StepsParam.Name = FString::Printf(TEXT("steps_%s"), *NodeId);
                    StepsParam.Type = TEXT("number");
                    StepsParam.DefaultValue = TEXT("20");
                    StepsParam.Description = TEXT("Number of sampling steps");
                    StepsParam.MinValue = 1.0f;
                    StepsParam.MaxValue = 100.0f;
                    OutConfig.ParameterDefinitions.Add(StepsParam);
                }
                
                // CFG参数
                if (InputsObj->HasField(TEXT("cfg")))
                {
                    FWorkflowConfig::FParameterDef CfgParam;
                    CfgParam.Name = FString::Printf(TEXT("cfg_%s"), *NodeId);
                    CfgParam.Type = TEXT("number");
                    CfgParam.DefaultValue = TEXT("7.0");
                    CfgParam.Description = TEXT("CFG Scale");
                    CfgParam.MinValue = 1.0f;
                    CfgParam.MaxValue = 30.0f;
                    OutConfig.ParameterDefinitions.Add(CfgParam);
                }
            }
        }
    }
    
    return true;
}

bool UComfyUIClient::FindWorkflowInputs(TSharedPtr<FJsonObject> WorkflowJson, TArray<FString>& OutInputs)
{
    OutInputs.Empty();
    
    if (!WorkflowJson.IsValid())
    {
        return false;
    }
    
    // 查找包含文本输入的节点
    TArray<FString> TextInputNodes = {
        TEXT("CLIPTextEncode"),
        TEXT("PromptText"),
        TEXT("StringConstant"),
        TEXT("Text")
    };
    
    for (const auto& NodePair : WorkflowJson->Values)
    {
        TSharedPtr<FJsonObject> NodeObj = NodePair.Value->AsObject();
        if (!NodeObj.IsValid())
        {
            continue;
        }
        
        FString ClassType = NodeObj->GetStringField(TEXT("class_type"));
        if (TextInputNodes.Contains(ClassType))
        {
            OutInputs.Add(NodePair.Key);
        }
    }
    
    return OutInputs.Num() > 0;
}

bool UComfyUIClient::FindWorkflowOutputs(TSharedPtr<FJsonObject> WorkflowJson, TArray<FString>& OutOutputs)
{
    OutOutputs.Empty();
    
    if (!WorkflowJson.IsValid())
    {
        return false;
    }
    
    // 查找输出节点
    TArray<FString> OutputNodeTypes = {
        TEXT("SaveImage"),
        TEXT("PreviewImage"),
        TEXT("SaveImageWebsocket"),
        TEXT("ImageOutput")
    };
    
    for (const auto& NodePair : WorkflowJson->Values)
    {
        TSharedPtr<FJsonObject> NodeObj = NodePair.Value->AsObject();
        if (!NodeObj.IsValid())
        {
            continue;
        }
        
        FString ClassType = NodeObj->GetStringField(TEXT("class_type"));
        if (OutputNodeTypes.Contains(ClassType))
        {
            OutOutputs.Add(NodePair.Key);
        }
    }
    
    return OutOutputs.Num() > 0;
}

FString UComfyUIClient::SanitizeWorkflowName(const FString& Name)
{
    FString SanitizedName = Name;
    
    // 移除或替换不安全的字符
    SanitizedName = SanitizedName.Replace(TEXT(" "), TEXT("_"));
    SanitizedName = SanitizedName.Replace(TEXT("/"), TEXT("_"));
    SanitizedName = SanitizedName.Replace(TEXT("\\"), TEXT("_"));
    SanitizedName = SanitizedName.Replace(TEXT(":"), TEXT("_"));
    SanitizedName = SanitizedName.Replace(TEXT("*"), TEXT("_"));
    SanitizedName = SanitizedName.Replace(TEXT("?"), TEXT("_"));
    SanitizedName = SanitizedName.Replace(TEXT("\""), TEXT("_"));
    SanitizedName = SanitizedName.Replace(TEXT("<"), TEXT("_"));
    SanitizedName = SanitizedName.Replace(TEXT(">"), TEXT("_"));
    SanitizedName = SanitizedName.Replace(TEXT("|"), TEXT("_"));
    
    // 确保不为空
    if (SanitizedName.IsEmpty())
    {
        SanitizedName = TEXT("CustomWorkflow");
    }
    
    return SanitizedName;
}
