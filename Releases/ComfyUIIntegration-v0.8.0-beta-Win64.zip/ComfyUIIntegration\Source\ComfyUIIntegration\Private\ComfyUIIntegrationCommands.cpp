#include "ComfyUIIntegrationCommands.h"

#define LOCTEXT_NAMESPACE "FComfyUIIntegrationModule"

void FComfyUIIntegrationCommands::RegisterCommands()
{
    UI_COMMAND(OpenPluginWindow, "ComfyUI 集成", "打开ComfyUI集成窗口", EUserInterfaceActionType::Button, FInputChord());
}

#undef LOCTEXT_NAMESPACE
