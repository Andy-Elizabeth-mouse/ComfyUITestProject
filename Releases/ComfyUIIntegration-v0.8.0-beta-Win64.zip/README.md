﻿# ComfyUI Integration Plugin v0.8.0-beta

**构建时间**: 2025-07-21 18:07:16  
**支持版本**: Unreal Engine 5.3+  
**平台支持**: Windows 10/11  

## 快速安装

### 自动安装（推荐）
1. 双击运行 Install.bat
2. 输入您的UE5项目完整路径
3. 按照提示完成安装

### 手动安装
1. 将 ComfyUIIntegration 文件夹复制到项目的 Plugins 目录
2. 右键项目的 .uproject 文件，选择 "Generate Visual Studio project files"  
3. 重新编译项目（如需要）
4. 启动虚幻引擎编辑器

## 新功能亮点

### 拖拽功能
- 直接从内容浏览器拖拽纹理资产到输入框
- 实时视觉反馈和智能验证
- 支持多种纹理格式

## 完整文档

详细文档请查看：
- 安装指南: ComfyUIIntegration/INSTALLATION_GUIDE.md
- 发布说明: ComfyUIIntegration/RELEASE_NOTES_v0.8.0-beta.md
- 测试指南: ComfyUIIntegration/TESTING_GUIDE.md

## 系统要求

- Unreal Engine 5.3+
- Windows 10/11 (64位)
- ComfyUI 服务

## 快速开始

1. 启动ComfyUI服务 (默认: http://127.0.0.1:8188)
2. 在UE5中: Tools > ComfyUI Integration
3. 配置服务器地址并开始使用！

---
版本: v0.8.0-beta | 构建: 2025-07-21 18:07:16
